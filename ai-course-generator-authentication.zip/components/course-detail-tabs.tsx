"use client"

import type React from "react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface CourseDetailTabsProps {
  overview: React.ReactNode
  videoLesson: React.ReactNode
  courseNotes: React.ReactNode
  objectives: React.ReactNode
}

export function CourseDetailTabs({ overview, videoLesson, courseNotes, objectives }: CourseDetailTabsProps) {
  return (
    <Tabs defaultValue="overview" className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="video-lesson">Video Lesson</TabsTrigger>
        <TabsTrigger value="course-notes">Course Notes</TabsTrigger>
        <TabsTrigger value="objectives">Objectives</TabsTrigger>
      </TabsList>
      <TabsContent value="overview" className="mt-4">
        {overview}
      </TabsContent>
      <TabsContent value="video-lesson" className="mt-4">
        {videoLesson}
      </TabsContent>
      <TabsContent value="course-notes" className="mt-4">
        {courseNotes}
      </TabsContent>
      <TabsContent value="objectives" className="mt-4">
        {objectives}
      </TabsContent>
    </Tabs>
  )
}
