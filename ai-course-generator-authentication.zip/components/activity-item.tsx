import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Award, BookOpen } from "lucide-react"

interface ActivityItemProps {
  activity: {
    type: "completed" | "earned" | "started"
    description: string
    timeAgo: string
  }
}

export function ActivityItem({ activity }: ActivityItemProps) {
  const Icon = activity.type === "completed" ? CheckCircle : activity.type === "earned" ? Award : BookOpen

  return (
    <Card className="shadow-none border-0">
      <CardContent className="flex items-start gap-3 p-0">
        <Icon className="h-5 w-5 text-blue-600 dark:text-blue-400 shrink-0 mt-1" />
        <div className="flex-1">
          <p className="text-sm font-medium">{activity.description}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400">{activity.timeAgo}</p>
        </div>
      </CardContent>
    </Card>
  )
}
