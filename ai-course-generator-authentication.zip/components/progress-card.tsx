import { Card, CardContent, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { BookOpen, Play } from "lucide-react"
import Link from "next/link"

interface ProgressCardProps {
  course: {
    id: string
    title: string
    nextLesson: string
    progress: number // 0-100
    completedLessons: number
    totalLessons: number
  }
}

export function ProgressCard({ course }: ProgressCardProps) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-4">
        <BookOpen className="h-10 w-10 text-blue-600 dark:text-blue-400" />
        <div className="flex-1 space-y-1">
          <CardTitle className="text-lg">{course.title}</CardTitle>
          <p className="text-sm text-gray-500 dark:text-gray-400">Next: {course.nextLesson}</p>
          <div className="flex items-center gap-2">
            <Progress value={course.progress} className="h-2 flex-1" />
            <span className="text-sm font-medium">{course.progress}% complete</span>
            <span className="text-xs text-gray-500 dark:text-gray-400">
              {course.completedLessons}/{course.totalLessons} lessons
            </span>
          </div>
        </div>
        <Button asChild size="icon" className="shrink-0">
          <Link href={`/courses/${course.id}`}>
            <Play className="h-5 w-5" />
            <span className="sr-only">Continue</span>
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
