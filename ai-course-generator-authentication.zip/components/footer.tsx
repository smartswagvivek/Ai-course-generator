import Link from "next/link"
import { BrainCircuit, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gray-100 dark:bg-gray-900 py-8 md:py-12 border-t">
      <div className="container mx-auto px-4 md:px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="space-y-4">
          <Link href="/" className="flex items-center gap-2 text-lg font-semibold">
            <BrainCircuit className="h-6 w-6" />
            <span>AI Course Generator</span>
          </Link>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Empowering your AI journey with personalized learning.
          </p>
          <div className="flex space-x-4">
            <Link href="#" className="text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50">
              <Facebook className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </Link>
            <Link href="#" className="text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50">
              <Twitter className="h-5 w-5" />
              <span className="sr-only">Twitter</span>
            </Link>
            <Link href="#" className="text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50">
              <Instagram className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link href="#" className="text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50">
              <Linkedin className="h-5 w-5" />
              <span className="sr-only">LinkedIn</span>
            </Link>
          </div>
        </div>
        <div className="space-y-2">
          <h3 className="text-base font-semibold">Quick Links</h3>
          <nav className="space-y-1 text-sm">
            <Link
              href="/domains"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              Courses
            </Link>
            <Link
              href="/dashboard"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              Dashboard
            </Link>
            <Link
              href="/about"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              About Us
            </Link>
            <Link
              href="/contact"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              Contact
            </Link>
          </nav>
        </div>
        <div className="space-y-2">
          <h3 className="text-base font-semibold">Legal</h3>
          <nav className="space-y-1 text-sm">
            <Link
              href="#"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              Privacy Policy
            </Link>
            <Link
              href="#"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              Terms of Service
            </Link>
            <Link
              href="#"
              className="block text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-50"
            >
              Cookie Policy
            </Link>
          </nav>
        </div>
        <div className="space-y-2">
          <h3 className="text-base font-semibold">Contact Us</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            123 AI Learning Lane, Suite 400
            <br />
            Innovation City, CA 90210
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Email: info@aicoursegen.com
            <br />
            Phone: +1 (234) 567-890
          </p>
        </div>
      </div>
      <div className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
        &copy; {new Date().getFullYear()} AI Course Generator. All rights reserved.
      </div>
    </footer>
  )
}
