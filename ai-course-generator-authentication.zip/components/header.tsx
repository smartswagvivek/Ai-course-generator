import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BrainCircuit } from "lucide-react"

export function Header() {
  return (
    <header className="flex h-16 items-center justify-between px-4 md:px-6 border-b bg-background">
      <Link href="/" className="flex items-center gap-2 text-lg font-semibold md:text-base">
        <BrainCircuit className="h-6 w-6" />
        <span className="sr-only">AI Course Generator</span>
        <span>AI Course Generator</span>
      </Link>
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
        <Link href="/domains" className="text-foreground transition-colors hover:text-primary">
          Courses
        </Link>
        <Link href="/dashboard" className="text-foreground transition-colors hover:text-primary">
          Dashboard
        </Link>
        <Link href="/about" className="text-foreground transition-colors hover:text-primary">
          About
        </Link>
        <Link href="/contact" className="text-foreground transition-colors hover:text-primary">
          Contact
        </Link>
      </nav>
      <div className="flex items-center gap-4">
        <Button asChild variant="outline" className="hidden md:inline-flex bg-transparent">
          <Link href="/login">Sign In</Link>
        </Button>
        <Button asChild className="hidden md:inline-flex">
          <Link href="/dashboard">Dashboard</Link>
        </Button>
      </div>
    </header>
  )
}
