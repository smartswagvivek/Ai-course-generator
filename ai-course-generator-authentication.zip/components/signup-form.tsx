"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Separator } from "@/components/ui/separator"
import { Chrome, Facebook } from "lucide-react"
import { useState } from "react"

export function SignUpForm() {
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" } | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setMessage(null)
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Simulate success or failure
    const success = Math.random() > 0.2 // 80% chance of success for demo

    if (success) {
      setMessage({ text: "Account created successfully! You can now log in.", type: "success" })
    } else {
      setMessage({ text: "Registration failed. Please try again.", type: "error" })
    }
    setIsSubmitting(false)
  }

  const handleSocialSignUp = (provider: string) => {
    setMessage({ text: `Simulating signup with ${provider}. Feature not fully implemented.`, type: "error" })
    console.log(`Attempting to sign up with ${provider}`)
  }

  return (
    <Card className="mx-auto max-w-sm">
      <CardHeader className="space-y-1 text-center">
        <CardTitle className="text-2xl">Sign Up</CardTitle>
        <CardDescription>Enter your information to create an account</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="first-name">First name</Label>
              <Input id="first-name" placeholder="Max" required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="last-name">Last name</Label>
              <Input id="last-name" placeholder="Robinson" required />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="m@example.com" required />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" required />
          </div>
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Creating Account..." : "Create an account"}
          </Button>
          {message && (
            <p className={`text-center text-sm ${message.type === "success" ? "text-green-600" : "text-red-600"}`}>
              {message.text}
            </p>
          )}
          <div className="flex items-center">
            <Separator className="flex-1" />
            <span className="px-2 text-sm text-gray-500 dark:text-gray-400">OR CONTINUE WITH</span>
            <Separator className="flex-1" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant="outline"
              className="w-full bg-transparent"
              disabled={isSubmitting}
              onClick={() => handleSocialSignUp("Google")}
            >
              <Chrome className="mr-2 h-4 w-4" /> Google
            </Button>
            <Button
              variant="outline"
              className="w-full bg-transparent"
              disabled={isSubmitting}
              onClick={() => handleSocialSignUp("Facebook")}
            >
              <Facebook className="mr-2 h-4 w-4" /> Facebook
            </Button>
          </div>
        </form>
        <div className="mt-4 text-center text-sm">
          Already have an account?{" "}
          <Link href="/login" className="underline">
            Sign in
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
