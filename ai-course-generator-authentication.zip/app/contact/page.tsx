import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Mail, Phone, MapPin } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 lg:py-24">
      <div className="text-center space-y-6 mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
          Get in <span className="text-blue-600 dark:text-blue-400">Touch</span>
        </h1>
        <p className="mx-auto max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
          Have questions, feedback, or just want to say hello? We'd love to hear from you!
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12">
        <Card className="p-6">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Send Us a Message</CardTitle>
            <CardDescription>Fill out the form below and we'll get back to you as soon as possible.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" placeholder="Your Name" required />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="your@example.com" required />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="subject">Subject</Label>
                <Input id="subject" placeholder="Regarding..." required />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="message">Message</Label>
                <Textarea id="message" placeholder="Your message..." rows={5} required />
              </div>
              <Button type="submit" className="w-full">
                Send Message
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-8 md:pt-12">
          <div className="flex items-start gap-4">
            <Mail className="h-6 w-6 text-blue-600 dark:text-blue-400 shrink-0" />
            <div>
              <h3 className="text-lg font-semibold">Email Us</h3>
              <p className="text-gray-600 dark:text-gray-300">
                For general inquiries, please email us at:
                <br />
                <a href="mailto:info@aicoursegen.com" className="underline">
                  info@aicoursegen.com
                </a>
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <Phone className="h-6 w-6 text-blue-600 dark:text-blue-400 shrink-0" />
            <div>
              <h3 className="text-lg font-semibold">Call Us</h3>
              <p className="text-gray-600 dark:text-gray-300">
                You can reach us by phone during business hours:
                <br />
                <a href="tel:+1234567890" className="underline">
                  +1 (234) 567-890
                </a>
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <MapPin className="h-6 w-6 text-blue-600 dark:text-blue-400 shrink-0" />
            <div>
              <h3 className="text-lg font-semibold">Our Office</h3>
              <p className="text-gray-600 dark:text-gray-300">
                AI Course Generator HQ
                <br />
                123 AI Learning Lane, Suite 400
                <br />
                Innovation City, CA 90210
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
