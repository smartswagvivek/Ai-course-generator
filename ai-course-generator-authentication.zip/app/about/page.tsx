import { Lightbulb, Users, GraduationCap } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12 md:px-6 lg:py-24">
      <div className="text-center space-y-6 mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
          About <span className="text-blue-600 dark:text-blue-400">AI Course Generator</span>
        </h1>
        <p className="mx-auto max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
          Our mission is to democratize AI education by providing personalized, high-quality courses to learners
          worldwide. We believe in empowering individuals with the knowledge and skills to thrive in the age of
          artificial intelligence.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
          <Lightbulb className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Our Vision</h2>
          <p className="text-gray-600 dark:text-gray-300">
            To be the leading platform for AI education, fostering innovation and accessibility for all.
          </p>
        </div>
        <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
          <Users className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Our Community</h2>
          <p className="text-gray-600 dark:text-gray-300">
            Join a vibrant community of AI enthusiasts, learners, and experts from diverse backgrounds.
          </p>
        </div>
        <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
          <GraduationCap className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
          <h2 className="text-xl font-semibold mb-2">Learning Experience</h2>
          <p className="text-gray-600 dark:text-gray-300">
            Engage with interactive lessons, hands-on projects, and expert-led content designed for effective learning.
          </p>
        </div>
      </div>

      <div className="mt-16 text-center space-y-4">
        <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Story</h2>
        <p className="mx-auto max-w-[800px] text-gray-600 dark:text-gray-300">
          Founded by a team of passionate AI researchers and educators, AI Course Generator was born out of a desire to
          bridge the gap between complex AI concepts and accessible learning. We started with a simple idea: to create a
          platform where anyone, regardless of their background, could learn AI at their own pace and according to their
          own interests. Since then, we've grown into a thriving community, constantly evolving our curriculum and
          technology to meet the demands of the rapidly changing AI landscape.
        </p>
      </div>
    </div>
  )
}
