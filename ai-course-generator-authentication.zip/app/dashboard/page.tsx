import { ProgressCard } from "@/components/progress-card"
import { ActivityItem } from "@/components/activity-item"
import { dashboardData } from "@/lib/data"
import { Card, CardContent } from "@/components/ui/card"

export default function DashboardPage() {
  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12">
      <h1 className="text-3xl font-bold tracking-tighter mb-8">Your Dashboard</h1>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold mb-4">Your Progress</h2>
        <div className="grid gap-4">
          {dashboardData.progress.map((course) => (
            <ProgressCard key={course.id} course={course} />
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Recent Activity</h2>
        <Card>
          <CardContent className="p-6 space-y-4">
            {dashboardData.recentActivity.map((activity, index) => (
              <ActivityItem key={index} activity={activity} />
            ))}
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
