import { SignUpForm } from "@/components/signup-form"
import { BrainCircuit } from "lucide-react"

export default function SignUpPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 dark:bg-gray-950 p-4">
      <div className="mb-8 flex items-center gap-2 text-2xl font-bold">
        <BrainCircuit className="h-8 w-8" />
        <span>AI Course Generator</span>
      </div>
      <SignUpForm />
    </div>
  )
}
