import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Brain, Zap, Award, Users, Lightbulb } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
          <div className="container px-4 md:px-6 text-center">
            <div className="space-y-6">
              <Badge variant="secondary" className="inline-flex items-center gap-2 px-3 py-1 text-sm font-medium">
                <span className="relative flex h-2 w-2 rounded-full bg-blue-500" />
                Powered by AI Technology
              </Badge>
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl/none">
                Learn AI with <span className="text-blue-600 dark:text-blue-400">Personalized Courses</span>
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Discover cutting-edge AI courses tailored to your learning style. From machine learning basics to
                advanced neural networks, start your AI journey today.
              </p>
              <div className="flex flex-col gap-4 sm:flex-row justify-center">
                <Button asChild className="px-8 py-3 text-lg">
                  <Link href="/domains">
                    Explore Courses <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" className="px-8 py-3 text-lg bg-transparent">
                  <Link href="/dashboard">View Dashboard</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-white dark:bg-gray-950">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Why Choose AI Course Generator?</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  We offer a unique learning experience designed to help you master AI concepts effectively.
                </p>
              </div>
            </div>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
                <Brain className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Personalized Learning Paths</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Our AI-powered system adapts to your pace and preferences, creating a custom learning journey.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
                <Zap className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Cutting-Edge Content</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Stay updated with the latest advancements in AI, machine learning, and deep learning.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
                <Award className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Expert Instructors</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Learn from industry leaders and academic experts with real-world experience.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
                <Users className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Vibrant Community</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Connect with fellow learners, share insights, and collaborate on projects.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
                <Lightbulb className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Hands-on Projects</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Apply your knowledge with practical exercises and build a strong portfolio.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-sm">
                <ArrowRight className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold mb-2">Flexible Learning</h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Learn anytime, anywhere, at your own pace with our flexible course structure.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-500 to-blue-700 text-white">
          <div className="container px-4 md:px-6 text-center space-y-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ready to Start Your AI Journey?</h2>
            <p className="mx-auto max-w-[700px] text-blue-100 md:text-xl">
              Join thousands of learners who are transforming their careers with AI Course Generator.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row justify-center">
              <Button asChild className="px-8 py-3 text-lg bg-white text-blue-600 hover:bg-gray-100">
                <Link href="/signup">Sign Up for Free</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="px-8 py-3 text-lg border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
              >
                <Link href="/contact">Contact Sales</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
