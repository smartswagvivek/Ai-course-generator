import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Code, Heart, MoreHorizontal } from "lucide-react"

export default function DomainsPage() {
  const domains = [
    {
      name: "Technical",
      description: "Dive into Machine Learning, Deep Learning, NLP, and more.",
      icon: Code,
      param: "technical",
    },
    {
      name: "Yoga",
      description: "Explore courses on various yoga styles, meditation, and wellness.",
      icon: Heart,
      param: "yoga",
    },
    {
      name: "Others",
      description: "Discover diverse topics beyond AI and traditional wellness.",
      icon: MoreHorizontal,
      param: "others",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12 text-center">
      <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl mb-8">Choose a Course Domain</h1>
      <p className="max-w-[700px] mx-auto text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400 mb-12">
        Select a domain to explore personalized courses tailored to your interests.
      </p>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-4xl mx-auto">
        {domains.map((domain) => (
          <Link key={domain.param} href={`/courses?domain=${domain.param}`}>
            <Card className="flex flex-col items-center justify-center p-6 text-center hover:shadow-lg transition-shadow h-full">
              <CardHeader>
                <domain.icon className="h-12 w-12 text-blue-600 dark:text-blue-400 mb-4" />
                <CardTitle className="text-xl">{domain.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500 dark:text-gray-400">{domain.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
