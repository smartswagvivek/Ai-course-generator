import { CourseCard } from "@/components/course-card"
import { courses } from "@/lib/data"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function CoursesPage({ searchParams }: { searchParams: { domain?: string } }) {
  const selectedDomain = searchParams.domain

  if (!selectedDomain) {
    return (
      <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12 text-center">
        <h1 className="text-3xl font-bold mb-4">Please select a domain to view courses.</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-6">You can choose from Technical, Yoga, or Other domains.</p>
        <Button asChild>
          <Link href="/domains">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Domain Selection
          </Link>
        </Button>
      </div>
    )
  }

  const filteredCourses = courses.filter((course) => course.domain === selectedDomain)

  if (filteredCourses.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12 text-center">
        <h1 className="text-3xl font-bold mb-4">No courses found for "{selectedDomain}" domain.</h1>
        <p className="text-gray-500 dark:text-gray-400 mb-6">Please try another domain.</p>
        <Button asChild>
          <Link href="/domains">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Domain Selection
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12">
      <div className="mb-6">
        <Button
          variant="ghost"
          asChild
          className="text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950"
        >
          <Link href="/domains">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Domains
          </Link>
        </Button>
      </div>
      <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">
            Courses in {selectedDomain.charAt(0).toUpperCase() + selectedDomain.slice(1)}
          </h1>
          <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
            Explore our curated selection of courses in the {selectedDomain} domain.
          </p>
        </div>
      </div>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredCourses.slice(0, 8).map((course) => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>
    </div>
  )
}
