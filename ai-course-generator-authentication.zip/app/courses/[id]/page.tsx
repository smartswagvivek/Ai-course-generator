"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Clock, Users, Star, PlayCircle, FileText } from "lucide-react"
import Link from "next/link"
import { courses } from "@/lib/data"
import { CourseDetailTabs } from "@/components/course-detail-tabs"
// Removed useState import as it's no longer needed for startCourseMessage

export default function CourseDetailPage({ params }: { params: { id: string } }) {
  const course = courses.find((c) => c.id === params.id)
  // Removed startCourseMessage state

  const handleStartCourse = () => {
    if (course?.youtubeLink) {
      window.open(course.youtubeLink, "_blank") // Open YouTube link in a new tab
    } else {
      console.warn("No YouTube link available for this course.")
      // Optionally, you could add a toast notification here if no link exists
    }
  }

  if (!course) {
    return (
      <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12 text-center">
        <h1 className="text-3xl font-bold">Course Not Found</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-2">The course you are looking for does not exist.</p>
        <Button asChild className="mt-4">
          <Link href="/domains">Back to Domains</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 md:px-6 lg:py-12">
      <div className="mb-6">
        <Button
          variant="ghost"
          asChild
          className="text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950"
        >
          <Link href={`/courses?domain=${course.domain}`}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to{" "}
            {course.domain.charAt(0).toUpperCase() + course.domain.slice(1)} Courses
          </Link>
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{course.level}</Badge>
            {course.tags.map((tag) => (
              <Badge key={tag} variant="outline">
                {tag}
              </Badge>
            ))}
          </div>
          <h1 className="text-4xl font-bold tracking-tight">{course.title}</h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">{course.description}</p>

          <div className="flex items-center gap-6 text-gray-500 dark:text-gray-400 text-sm">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{course.students.toLocaleString()} students</span>
            </div>
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span>{course.rating}</span>
            </div>
          </div>
          <p className="text-gray-700 dark:text-gray-200 text-base">
            Instructor: <span className="font-medium">{course.instructor}</span>
          </p>

          <CourseDetailTabs
            overview={
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Course Overview</h2>
                <p className="text-gray-700 dark:text-gray-300">
                  This comprehensive course provides a deep dive into {course.title.toLowerCase()}, covering both
                  theoretical foundations and practical applications. You will learn to build and train sophisticated
                  models for various real-world problems.
                </p>
                <h3 className="text-xl font-semibold mt-6">What you'll learn:</h3>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1">
                  <li>Master neural networks and deep learning using PyTorch framework.</li>
                  <li>Build and train sophisticated models for computer vision and natural language processing.</li>
                  <li>Understand the core concepts of backpropagation and optimization.</li>
                  <li>Implement various architectures like CNNs, RNNs, and Transformers.</li>
                </ul>
              </div>
            }
            videoLesson={
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Video Lesson</h2>
                {course.youtubeLink ? (
                  <div className="aspect-video w-full rounded-lg overflow-hidden bg-gray-200 dark:bg-gray-800">
                    <iframe
                      width="100%"
                      height="100%"
                      src={course.youtubeLink}
                      title="YouTube video player"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                ) : (
                  <div className="aspect-video w-full rounded-lg overflow-hidden bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
                    <PlayCircle className="h-24 w-24 text-gray-400 dark:text-gray-600" />
                    <span className="sr-only">No video available</span>
                  </div>
                )}
                <p className="text-gray-700 dark:text-gray-300">This is the primary video lesson for this course.</p>
              </div>
            }
            courseNotes={
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Course Notes</h2>
                {course.notesLink ? (
                  <Button asChild variant="outline" className="bg-transparent">
                    <Link href={course.notesLink} target="_blank" rel="noopener noreferrer">
                      <FileText className="mr-2 h-4 w-4" /> Download Course Notes
                    </Link>
                  </Button>
                ) : (
                  <p className="text-gray-700 dark:text-gray-300">No notes available for this course yet.</p>
                )}
                <p className="text-gray-700 dark:text-gray-300">
                  Detailed notes and supplementary materials for this course will be available here. You can download
                  PDFs, code snippets, and other resources to aid your learning.
                </p>
              </div>
            }
            objectives={
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Learning Objectives</h2>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1">
                  <li>Understand the fundamental concepts of deep learning.</li>
                  <li>Gain proficiency in using the PyTorch framework.</li>
                  <li>Develop and train various deep learning models.</li>
                  <li>Apply deep learning techniques to real-world problems in computer vision and NLP.</li>
                </ul>
                <h2 className="text-2xl font-bold mt-6">Prerequisites</h2>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1">
                  <li>Basic understanding of Python programming.</li>
                  <li>Familiarity with linear algebra and calculus concepts.</li>
                  <li>Prior experience with machine learning concepts is a plus, but not required.</li>
                </ul>
              </div>
            }
          />
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-xl">Start Learning Now</CardTitle>
              <p className="text-sm text-gray-500 dark:text-gray-400">Free course - No payment required</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button className="w-full text-lg py-6" onClick={handleStartCourse} disabled={!course.youtubeLink}>
                <PlayCircle className="mr-2 h-6 w-6" /> Start Course
              </Button>
              {/* Removed startCourseMessage display */}
              <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 dark:text-gray-300">
                <div>Duration:</div>
                <div className="font-medium text-right">{course.duration}</div>
                <div>Level:</div>
                <div className="font-medium text-right">{course.level}</div>
                <div>Students:</div>
                <div className="font-medium text-right">{course.students.toLocaleString()}</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
