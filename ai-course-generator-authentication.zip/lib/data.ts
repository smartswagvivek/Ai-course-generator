export const courses = [
  // Technical Courses (8 courses)
  {
    id: "machine-learning",
    title: "Introduction to Machine Learning",
    description: "Learn the fundamentals of ML with hands-on projects and real-world applications.",
    duration: "8 weeks",
    students: 1234,
    rating: 4.8,
    level: "Beginner",
    instructor: "Dr. Emily Chen",
    tags: ["Machine Learning", "Python", "Data Science"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/GwIo3gDZCVQ", // What is Machine Learning?
    notesLink: "#", // Placeholder
  },
  {
    id: "deep-learning-pytorch",
    title: "Deep Learning with PyTorch",
    description:
      "Master neural networks and deep learning using PyTorch framework. Build and train sophisticated models for computer vision and natural language processing.",
    duration: "12 weeks",
    students: 856,
    rating: 4.9,
    level: "Advanced",
    instructor: "Prof. Michael Rodriguez",
    tags: ["Deep Learning", "PyTorch", "Neural Networks"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/v_j_g2c-y-c", // PyTorch for Deep Learning
    notesLink: "#", // Placeholder
  },
  {
    id: "natural-language-processing",
    title: "Natural Language Processing",
    description: "Explore NLP techniques and build chatbots, sentiment analysis tools.",
    duration: "10 weeks",
    students: 642,
    rating: 4.7,
    level: "Intermediate",
    instructor: "Dr. Sarah Lee",
    tags: ["NLP", "Python", "Text Analysis"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/C_A_J_2_y_A", // Introduction to NLP
    notesLink: "#", // Placeholder
  },
  {
    id: "computer-vision",
    title: "Computer Vision Fundamentals",
    description: "Understand image processing, object detection, and facial recognition.",
    duration: "9 weeks",
    students: 789,
    rating: 4.6,
    level: "Intermediate",
    instructor: "Dr. Alex Kim",
    tags: ["Computer Vision", "OpenCV", "Image Processing"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/GwIo3gDZCVQ", // What is Computer Vision?
    notesLink: "#", // Placeholder
  },
  {
    id: "reinforcement-learning",
    title: "Reinforcement Learning Basics",
    description: "Learn about agents, environments, rewards, and popular RL algorithms.",
    duration: "7 weeks",
    students: 321,
    rating: 4.5,
    level: "Beginner",
    instructor: "Prof. David Green",
    tags: ["Reinforcement Learning", "AI", "Algorithms"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/v_j_g2c-y-c", // Reinforcement Learning Explained
    notesLink: "#", // Placeholder
  },
  {
    id: "data-structures-algorithms",
    title: "Data Structures & Algorithms",
    description: "Master essential data structures and algorithms for coding interviews.",
    duration: "10 weeks",
    students: 1500,
    rating: 4.9,
    level: "Intermediate",
    instructor: "Dr. John Smith",
    tags: ["Algorithms", "Data Structures", "Programming"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/C_A_J_2_y_A", // Data Structures and Algorithms in Python
    notesLink: "#", // Placeholder
  },
  {
    id: "web-development-react",
    title: "Full-Stack Web Development with React",
    description: "Build modern web applications using React, Next.js, and Node.js.",
    duration: "14 weeks",
    students: 2000,
    rating: 4.7,
    level: "Beginner",
    instructor: "Ms. Jane Doe",
    tags: ["Web Development", "React", "Next.js", "Node.js"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/GwIo3gDZCVQ", // React JS Crash Course
    notesLink: "#", // Placeholder
  },
  {
    id: "cloud-computing-aws",
    title: "Cloud Computing with AWS",
    description: "Learn to deploy and manage applications on Amazon Web Services.",
    duration: "11 weeks",
    students: 950,
    rating: 4.6,
    level: "Intermediate",
    instructor: "Mr. Robert Johnson",
    tags: ["Cloud Computing", "AWS", "DevOps"],
    domain: "technical",
    youtubeLink: "https://www.youtube.com/embed/v_j_g2c-y-c", // AWS Tutorial for Beginners
    notesLink: "#", // Placeholder
  },

  // Yoga Courses (8 courses)
  {
    id: "hatha-yoga-basics",
    title: "Hatha Yoga for Beginners",
    description: "Learn foundational Hatha Yoga poses, breathing techniques, and meditation.",
    duration: "6 weeks",
    students: 500,
    rating: 4.7,
    level: "Beginner",
    instructor: "Yoga Guru Priya",
    tags: ["Hatha Yoga", "Beginner", "Wellness"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Hatha Yoga for Beginners
    notesLink: "#", // Placeholder
  },
  {
    id: "vinyasa-flow",
    title: "Dynamic Vinyasa Flow",
    description: "Energize your body and mind with a flowing sequence of Vinyasa poses.",
    duration: "8 weeks",
    students: 700,
    rating: 4.8,
    level: "Intermediate",
    instructor: "Yoga Master David",
    tags: ["Vinyasa", "Flow Yoga", "Strength"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Vinyasa Flow Yoga
    notesLink: "#", // Placeholder
  },
  {
    id: "restorative-yoga",
    title: "Restorative Yoga for Stress Relief",
    description: "Deep relaxation and gentle stretches to calm your nervous system.",
    duration: "5 weeks",
    students: 400,
    rating: 4.9,
    level: "All Levels",
    instructor: "Wellness Coach Sarah",
    tags: ["Restorative", "Relaxation", "Stress Relief"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Restorative Yoga Class
    notesLink: "#", // Placeholder
  },
  {
    id: "pranayama-breathing",
    title: "Pranayama: Breathwork Techniques",
    description: "Explore various breathing exercises to enhance vitality and focus.",
    duration: "4 weeks",
    students: 300,
    rating: 4.6,
    level: "Beginner",
    instructor: "Meditation Guide Rahul",
    tags: ["Pranayama", "Breathwork", "Mindfulness"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Pranayama Breathing Exercises
    notesLink: "#", // Placeholder
  },
  {
    id: "ashtanga-primary",
    title: "Ashtanga Yoga Primary Series",
    description: "A challenging and disciplined practice following the traditional Ashtanga sequence.",
    duration: "10 weeks",
    students: 250,
    rating: 4.7,
    level: "Advanced",
    instructor: "Ashtanga Guru Maya",
    tags: ["Ashtanga", "Traditional Yoga", "Discipline"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Ashtanga Yoga Primary Series
    notesLink: "#", // Placeholder
  },
  {
    id: "yoga-for-back-pain",
    title: "Yoga for Back Pain Relief",
    description: "Gentle yoga poses and stretches to alleviate and prevent back discomfort.",
    duration: "6 weeks",
    students: 600,
    rating: 4.8,
    level: "All Levels",
    instructor: "Therapeutic Yoga Expert Lisa",
    tags: ["Therapeutic Yoga", "Pain Relief", "Flexibility"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Yoga for Back Pain
    notesLink: "#", // Placeholder
  },
  {
    id: "meditation-mindfulness",
    title: "Meditation and Mindfulness",
    description: "Learn various meditation techniques to cultivate inner peace and awareness.",
    duration: "7 weeks",
    students: 800,
    rating: 4.9,
    level: "Beginner",
    instructor: "Mindfulness Coach Ben",
    tags: ["Meditation", "Mindfulness", "Mental Health"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Guided Meditation for Beginners
    notesLink: "#", // Placeholder
  },
  {
    id: "prenatal-yoga",
    title: "Prenatal Yoga for Expecting Mothers",
    description: "Safe and supportive yoga practices for a healthy pregnancy.",
    duration: "8 weeks",
    students: 150,
    rating: 4.7,
    level: "Beginner",
    instructor: "Prenatal Yoga Specialist Chloe",
    tags: ["Prenatal", "Pregnancy", "Maternity"],
    domain: "yoga",
    youtubeLink: "https://www.youtube.com/embed/v7AYKMP6g5M", // Prenatal Yoga Class
    notesLink: "#", // Placeholder
  },

  // Others Courses (8 courses)
  {
    id: "digital-marketing",
    title: "Introduction to Digital Marketing",
    description: "Learn the basics of SEO, social media, content marketing, and more.",
    duration: "8 weeks",
    students: 900,
    rating: 4.5,
    level: "Beginner",
    instructor: "Marketing Expert Sarah",
    tags: ["Marketing", "Digital", "SEO"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/GwIo3gDZCVQ", // Digital Marketing Tutorial
    notesLink: "#", // Placeholder
  },
  {
    id: "creative-writing",
    title: "Creative Writing Workshop",
    description: "Unleash your creativity and master the art of storytelling.",
    duration: "10 weeks",
    students: 400,
    rating: 4.7,
    level: "All Levels",
    instructor: "Author Emily White",
    tags: ["Writing", "Creativity", "Storytelling"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/v_j_g2c-y-c", // Creative Writing Basics
    notesLink: "#", // Placeholder
  },
  {
    id: "financial-literacy",
    title: "Personal Financial Literacy",
    description: "Manage your money, invest wisely, and plan for your financial future.",
    duration: "7 weeks",
    students: 1100,
    rating: 4.8,
    level: "Beginner",
    instructor: "Financial Advisor Mark",
    tags: ["Finance", "Personal Finance", "Investing"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/C_A_J_2_y_A", // Personal Finance for Beginners
    notesLink: "#", // Placeholder
  },
  {
    id: "photography-basics",
    title: "Photography for Beginners",
    description: "Learn camera basics, composition, and editing techniques.",
    duration: "6 weeks",
    students: 750,
    rating: 4.6,
    level: "Beginner",
    instructor: "Photographer Alex Lee",
    tags: ["Photography", "Art", "Creative"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/GwIo3gDZCVQ", // Photography Basics Tutorial
    notesLink: "#", // Placeholder
  },
  {
    id: "cooking-culinary",
    title: "Culinary Arts: World Cuisines",
    description: "Explore cooking techniques and recipes from around the globe.",
    duration: "12 weeks",
    students: 600,
    rating: 4.9,
    level: "All Levels",
    instructor: "Chef Maria Garcia",
    tags: ["Cooking", "Culinary", "Food"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/v_j_g2c-y-c", // Basic Cooking Techniques
    notesLink: "#", // Placeholder
  },
  {
    id: "gardening-urban",
    title: "Urban Gardening & Permaculture",
    description: "Grow your own food in small spaces and sustainable practices.",
    duration: "9 weeks",
    students: 350,
    rating: 4.7,
    level: "Beginner",
    instructor: "Horticulturist Ben Carter",
    tags: ["Gardening", "Sustainability", "Urban Farming"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/C_A_J_2_y_A", // Urban Gardening Tips
    notesLink: "#", // Placeholder
  },
  {
    id: "language-spanish",
    title: "Conversational Spanish for Travelers",
    description: "Learn essential phrases and cultural insights for your next trip.",
    duration: "8 weeks",
    students: 850,
    rating: 4.5,
    level: "Beginner",
    instructor: "Language Instructor Elena",
    tags: ["Language", "Spanish", "Travel"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/GwIo3gDZCVQ", // Learn Spanish for Beginners
    notesLink: "#", // Placeholder
  },
  {
    id: "home-improvement",
    title: "DIY Home Improvement Basics",
    description: "Tackle common home repairs and renovation projects with confidence.",
    duration: "10 weeks",
    students: 500,
    rating: 4.6,
    level: "Beginner",
    instructor: "Handyman Mike",
    tags: ["DIY", "Home Repair", "Renovation"],
    domain: "others",
    youtubeLink: "https://www.youtube.com/embed/v_j_g2c-y-c", // DIY Home Repair Basics
    notesLink: "#", // Placeholder
  },
]

export const dashboardData = {
  progress: [
    {
      id: "machine-learning",
      title: "Introduction to Machine Learning",
      nextLesson: "Linear Regression Implementation",
      progress: 65,
      completedLessons: 16,
      totalLessons: 24,
    },
    {
      id: "natural-language-processing",
      title: "Natural Language Processing",
      nextLesson: "Text Preprocessing Techniques",
      progress: 30,
      completedLessons: 5,
      totalLessons: 18,
    },
  ],
  recentActivity: [
    {
      type: "completed",
      description: 'Completed "Supervised Learning Basics"',
      timeAgo: "2 hours ago",
    },
    {
      type: "earned",
      description: 'Earned "Quick Learner" badge',
      timeAgo: "1 day ago",
    },
    {
      type: "started",
      description: 'Started "Natural Language Processing"',
      timeAgo: "3 days ago",
    },
    {
      type: "completed",
      description: 'Completed "Python for Data Science"',
      timeAgo: "1 week ago",
    },
  ],
}
